from django.apps import AppConfig

class ReservaAulasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reserva_aulas'
