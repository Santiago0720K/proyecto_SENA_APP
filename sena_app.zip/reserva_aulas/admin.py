from django.contrib import admin
from .models import Aula

# Registrar el modelo Aula para que sea visible en el panel de administración
admin.site.register(Aula)

